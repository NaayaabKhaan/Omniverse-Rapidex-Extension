import omni
import omni.ext
import omni.ui as ui
import omni.kit.commands
import omni.usd
import omni.kit.converter.geojson
from omni.kit.converter.geojson import _geojson_converter
#import cesiumion
from cesium.usd.plugins.CesiumUsdSchemas import (GlobeAnchorAPI as CesiumGlobeAnchorAPI)


#initialize prim path here
#intialize stage_url= test.usd here
#add download_url=edges.geojson geojson file link here

context = omni.usd.get_context()
stage_url = context.get_stage()
prim_path = "/World/Geospatial/GeoJSON/Hamburg_3_0/Features/LineStrings/LineString_1"
download_url="/C:/users/sakshi/documents/kit-exts-project-rapidex/exts/RapidexExtension/RapidexExtension/edges.geojson"
#prim_path = "/World/Cube"

prim = stage_url.GetPrimAtPath(prim_path)

#globe_anchor = CesiumGlobeAnchorAPI.Apply(prim)
globe_anchor = CesiumGlobeAnchorAPI.Get(stage_url, prim_path)

lat = globe_anchor.GetAnchorLatitudeAttr().Get()

lon = globe_anchor.GetAnchorLongitudeAttr().Get()

height = globe_anchor.GetAnchorHeightAttr().Get()

print(lat, lon, height)

_geojson_interface = _geojson_converter.acquire_interface()
_geojson_interface.convert_geojson_python(stage_url, download_url, recursive)#provide the url here


# helper for plugin
class GeoJSONHelper():
    # opens module
    def __init__(self):
        self._geojson_interface = _geojson_converter.acquire_interface()
    # closes module
    def destroy(self):
        if self._geojson_interface:
            _geojson_converter.release_interface(self._geojson_interface)
            self._geojson_interface = None
    # calls extension.py
    def convert_geojson_python(self, stage_url : str, download_url : str, recursive : bool):
        # checks for user input
        return self._geojson_interface.convert_geojson_python(stage_url, download_url, recursive)

# Functions and vars are available to other extension as usual in python: `example.python_ext.some_public_function(x)`
def some_public_function(x: int):
    print("[RapidexExtension] some_public_function was called with x: ", x)
    return x ** x


# Any class derived from `omni.ext.IExt` in top level module (defined in `python.modules` of `extension.toml`) will be
# instantiated when extension gets enabled and `on_startup(ext_id)` will be called. Later when extension gets disabled
# on_shutdown() is called.
class RapidexextensionExtension(omni.ext.IExt):
    @staticmethod
    def _set_menu(path, value):
        # Set the menu to create this window on and off
        editor_menu = omni.kit.ui.get_editor_menu()
        if editor_menu:
            editor_menu.set_value(path, value)
    # ext_id is current extension id. It can be used with extension manager to query additional information, like where
    # this extension is located on filesystem.
 

        # Acquire the Cesium Omniverse interface.
        global _cesium_omniverse_interface
        _cesium_omniverse_interface = acquire_cesium_omniverse_interface()
        _cesium_omniverse_interface.on_startup(cesium_extension_location)#what location of ceium do we provide here?

        settings.set("/rtx/hydra/TBNFrameMode", 1)

        # Allow material graph to find cesium mdl exports
        mdl_custom_paths_name = "materialConfig/searchPaths/custom"
        mdl_user_allow_list_name = "materialConfig/materialGraph/userAllowList"
        mdl_renderer_custom_paths_name = "/renderer/mdl/searchPaths/custom"

        cesium_mdl_search_path = os.path.join(cesium_extension_location, "mdl")
        cesium_mdl_name = "cesium.mdl"

        mdl_custom_paths = settings.get(mdl_custom_paths_name) or []
        mdl_user_allow_list = settings.get(mdl_user_allow_list_name) or []

        mdl_custom_paths.append(cesium_mdl_search_path)
        mdl_user_allow_list.append(cesium_mdl_name)

        mdl_renderer_custom_paths = settings.get_as_string(mdl_renderer_custom_paths_name)
        mdl_renderer_custom_paths_sep = "" if mdl_renderer_custom_paths == "" else ";"
        mdl_renderer_custom_paths = mdl_renderer_custom_paths + mdl_renderer_custom_paths_sep + cesium_mdl_search_path

        settings.set_string_array(mdl_custom_paths_name, mdl_custom_paths)
        settings.set_string_array(mdl_user_allow_list_name, mdl_user_allow_list)
        settings.set_string(mdl_renderer_custom_paths_name, mdl_renderer_custom_paths)

        # Show the window. It will call `self.show_window`
        if show_on_startup:
            asyncio.ensure_future(perform_action_after_n_frames_async(15, CesiumOmniverseExtension._open_window))

        self._credits_viewport_controller = CreditsViewportController(_cesium_omniverse_interface)

        self._add_menu_controller = CesiumAddMenuController(_cesium_omniverse_interface)

        # Subscribe to stage event stream
        usd_context = omni.usd.get_context()
        if usd_context.get_stage_state() == omni.usd.StageState.OPENED:
            _cesium_omniverse_interface.on_stage_change(usd_context.get_stage_id())

        self._on_stage_subscription = usd_context.get_stage_event_stream().create_subscription_to_pop(
            self._on_stage_event, name="cesium.omniverse.ON_STAGE_EVENT"
        )

        self._on_update_subscription = (
            omni_app.get_app()
            .get_update_event_stream()
            .create_subscription_to_pop(self._on_update_frame, name="cesium.omniverse.extension.ON_UPDATE_FRAME")
        )

        bus = omni_app.get_app().get_message_bus_event_stream()
        show_asset_window_event = carb.events.type_from_string("cesium.omniverse.SHOW_ASSET_WINDOW")
        self._show_asset_window_subscription = bus.create_subscription_to_pop_by_type(
            show_asset_window_event, self._on_show_asset_window_event
        )

        token_set_event = carb.events.type_from_string("cesium.omniverse.SET_DEFAULT_TOKEN_SUCCESS")
        self._token_set_subscription = bus.create_subscription_to_pop_by_type(token_set_event, self._on_token_set)

        add_ion_asset_event = carb.events.type_from_string("cesium.omniverse.ADD_ION_ASSET")
        self._add_ion_asset_subscription = bus.create_subscription_to_pop_by_type(
            add_ion_asset_event, self._on_add_ion_asset_event
        )

        add_blank_asset_event = carb.events.type_from_string("cesium.omniverse.ADD_BLANK_ASSET")
        self._add_blank_asset_subscription = bus.create_subscription_to_pop_by_type(
            add_blank_asset_event, self._on_add_blank_asset_event
        )

        add_cartographic_polygon_event = carb.events.type_from_string("cesium.omniverse.ADD_CARTOGRAPHIC_POLYGON")
        self._add_cartographic_polygon_subscription = bus.create_subscription_to_pop_by_type(
            add_cartographic_polygon_event, self._on_add_cartographic_polygon_event
        )

        add_raster_overlay_event = carb.events.type_from_string("cesium.omniverse.ADD_RASTER_OVERLAY")
        self._add_raster_overlay_subscription = bus.create_subscription_to_pop_by_type(
            add_raster_overlay_event, self._on_add_raster_overlay_to_tileset
        )

        self._capture_instance = CaptureExtension.get_instance()

    def on_shutdown(self):
        self._menus.clear()

        if self._main_window is not None:
            self._main_window.destroy()
            self._main_window = None

        if self._asset_window is not None:
            self._asset_window.destroy()
            self._asset_window = None

        if self._debug_window is not None:
            self._debug_window.destroy()
            self._debug_window = None

        if self._settings_window is not None:
            self._settings_window.destroy()
            self._settings_window = None

        if self._credits_viewport_controller is not None:
            self._credits_viewport_controller.destroy()
            self._credits_viewport_controller = None

        # Deregister the function that shows the window from omni.ui
        ui.Workspace.set_show_window_fn(CesiumOmniverseMainWindow.WINDOW_NAME, None)
        ui.Workspace.set_show_window_fn(CesiumOmniverseAssetWindow.WINDOW_NAME, None)
        ui.Workspace.set_show_window_fn(CesiumOmniverseDebugWindow.WINDOW_NAME, None)
        ui.Workspace.set_show_window_fn(CesiumOmniverseSettingsWindow.WINDOW_NAME, None)

        if self._on_stage_subscription is not None:
            self._on_stage_subscription.unsubscribe()
            self._on_stage_subscription = None

        if self._on_update_subscription is not None:
            self._on_update_subscription.unsubscribe()
            self._on_update_subscription = None

        if self._token_set_subscription is not None:
            self._token_set_subscription.unsubscribe()
            self._token_set_subscription = None

        if self._add_ion_asset_subscription is not None:
            self._add_ion_asset_subscription.unsubscribe()
            self._add_ion_asset_subscription = None

        if self._add_blank_asset_subscription is not None:
            self._add_blank_asset_subscription.unsubscribe()
            self._add_blank_asset_subscription = None

        if self._add_raster_overlay_subscription is not None:
            self._add_raster_overlay_subscription.unsubscribe()
            self._add_raster_overlay_subscription = None

        if self._add_cartographic_polygon_subscription is not None:
            self._add_cartographic_polygon_subscription.unsubscribe()
            self._add_cartographic_polygon_subscription = None

        if self._show_asset_window_subscription is not None:
            self._show_asset_window_subscription.unsubscribe()
            self._show_asset_window_subscription = None

        if self._attributes_widget_controller is not None:
            self._attributes_widget_controller.destroy()
            self._attributes_widget_controller = None

        if self._add_menu_controller is not None:
            self._add_menu_controller.destroy()
            self._add_menu_controller = None

        self._capture_instance = None

        self._destroy_credits_viewport_frames()

        self._logger.info("CesiumOmniverse shutdown")

        # Release the Cesium Omniverse interface.
        _cesium_omniverse_interface.on_shutdown()
        release_cesium_omniverse_interface(_cesium_omniverse_interface)

    def _on_update_frame(self, _):
        if omni.usd.get_context().get_stage_state() != omni.usd.StageState.OPENED:
            return

        viewports = []
        for instance in get_viewport_window_instances():
            viewport_api = instance.viewport_api
            viewport = Viewport()
            viewport.viewMatrix = viewport_api.view
            viewport.projMatrix = viewport_api.projection
            viewport.width = float(viewport_api.resolution[0])
            viewport.height = float(viewport_api.resolution[1])
            viewports.append(viewport)

        if len(viewports) != self._num_credits_viewport_frames:
            self._setup_credits_viewport_frames()
            self._num_credits_viewport_frames = len(viewports)

        wait_for_loading_tiles = (
            self._capture_instance.progress.capture_status == omni.kit.capture.viewport.CaptureStatus.CAPTURING
        )
        _cesium_omniverse_interface.on_update_frame(viewports, wait_for_loading_tiles)

    def _on_stage_event(self, event):
        if _cesium_omniverse_interface is None:
            return

        if event.type == int(omni.usd.StageEventType.OPENED):
            _cesium_omniverse_interface.on_stage_change(omni.usd.get_context().get_stage_id())
            self._attributes_widget_controller = CesiumAttributesWidgetController(_cesium_omniverse_interface)

            # Show Fabric modal if Fabric is disabled.
            fabric_enabled = omni_settings.get_settings().get_as_bool("/app/useFabricSceneDelegate")
            if not fabric_enabled:
                asyncio.ensure_future(perform_action_after_n_frames_async(15, CesiumOmniverseExtension._open_modal))

            get_or_create_cesium_data()
            get_or_create_cesium_georeference()

            self._setup_ion_server_prims()
        elif event.type == int(omni.usd.StageEventType.CLOSED):
            _cesium_omniverse_interface.on_stage_change(0)
            if self._attributes_widget_controller is not None:
                self._attributes_widget_controller.destroy()
                self._attributes_widget_controller = None
        '''fp= "edges.geojson"
        data=gpd.read_file(fp)
        print(data.head())'''

        '''#self.obj_model= ObjInfoModel()
        self._window = ui.Window("My Window", width=300, height=300)
        with self._window.frame:
            with ui.VStack():
                label = ui.Label("Rapidex output Label")


                def on_click():
                    self._count += 1
                    label.text = f"count: {self._count}"
                    #print("clicked")
                    #print(viewport_window)

                def on_reset():
                    self._count = 0
                    label.text = "empty"

                on_reset()

                with ui.HStack():
                    ui.Button("Print", clicked_fn=on_click)
                    ui.Button("Reset", clicked_fn=on_reset)'''

        '''def convert_geojson_to_usd(input_geojson, output_usd):
            # Read GeoJSON file
            gdf = gpd.read_file(input_geojson)

            # Create USD stage
            stage = Usd.Stage.CreateNew(output_usd)

            # Iterate over each feature in the GeoJSON data
            for feature in input_geojson['features']:
             geometry_type = feature['geometry']['type']
             coordinates = feature['geometry']['coordinates']
             properties = feature['properties']

             # Create appropriate geometry based on the type
             if geometry_type == 'LineString':
              points = [UsdGeom.GfVec3f(coord[0], coord[1], coord[2]) for coord in coordinates]
              line = UsdGeom.Xform.Define(stage, '/{}'.format(properties['object_id']))
              UsdGeom.Points(line.GetPrim()).CreatePointsAttr().Set(points)

             elif geometry_type == 'Polygon':
              # Convert exterior ring coordinates to USD format
              points = [UsdGeom.GfVec3f(coord[0], coord[1], coord[2]) for coord in coordinates[0]]
              # Create a polygon prim
              polygon = UsdGeom.Polygon(stage.DefinePrim('/{}'.format(properties['object_id'])))
              # Set the points of the polygon
              polygon.CreatePointsAttr().Set(points)

             elif geometry_type == 'MultiPolygon':
              # Iterate over each polygon in the MultiPolygon
              for polygon_coords in coordinates:
                points = [UsdGeom.GfVec3f(coord[0], coord[1], coord[2]) for coord in polygon_coords[0]]
                # Create a polygon prim
                polygon = UsdGeom.Polygon(stage.DefinePrim('/{}'.format(properties['object_id'])))
                # Set the points of the polygon
                polygon.CreatePointsAttr().Set(points)

             # Set properties for the prim
             for key, value in properties.items():
              stage.GetPrimAtPath('/{}'.format(properties['object_id'])).GetAttribute(key).Set(value)

             # Save the USD stage to disk
            stage.GetRootLayer().Save()

            # Create USD geometry
            usd_points = UsdGeom.Points.Define(stage, "/NetworkPoints")
            points_attr = usd_points.CreatePointsAttr()
            points = []

            # Extract geometry from GeoDataFrame
            for index, row in gdf.iterrows():
                points.append(row.geometry.centroid.coords[0])  # Assuming each geometry is a polygon

            # Set points attribute
            points_attr.Set(points)

            # Save USD stage
            stage.GetRootLayer().Save()

        if __name__ == "__main__":
            input_geojson = "edges.geojson"  # Path to your GeoJSON file
            output_usd = "output.usd"  # Path for the output USD file

            convert_geojson_to_usd(input_geojson, output_usd)'''

    def on_shutdown(self):
        print("[RapidexExtension] RapidexExtension shutdown")
        self.obj_model.destroy()
